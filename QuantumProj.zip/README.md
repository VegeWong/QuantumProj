# QuantumProj

* 文件目录层次说明
  * Src: 代码存放目录
    * MultiThread: 多线程版本实现
    * SingleThread: 单线程版本实现
    * Qiskit: IBM Q Experience 电路图模拟
  * Docs:　项目描述文档
  * project.log: Debug Log

