import Shor


print(Shor.ShorWrapper([10]))